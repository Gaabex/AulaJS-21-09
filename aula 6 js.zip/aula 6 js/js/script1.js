"use strict";
let x = 4.659898;
let y = 5;
let z = Math.random()*1000;

console.log (x/y);
console.log (z);     
console.log (Math.ceil (x/y));
console.log (Math.floor (x/y));
console.log (Math.round (z));
console.log (Number(z.toFixed(2)));