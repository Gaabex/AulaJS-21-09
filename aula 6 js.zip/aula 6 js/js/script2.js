"use strict";

document.querySelector("#btn").addEventListener("click",function(){
        let txt = document.querySelector("#texto").value;
        inverter(txt);
        inserirSimbolo(txt, "*"); 
    });

    function inverter(t){
        let saida = "";
        for(let i=t.length-1; i >= 0; i--){
            saida += t[i].toUpperCase();
        }
        console.log(saida);
    }

    function inserirSimbolo(t, s){
        let saida ="";
        for (let i=0; i < t.length; i++){
            saida += t[i]+s;
        }
        console.log(saida);
    }