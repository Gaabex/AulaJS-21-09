"use strict"

let frutas = [];
let meses = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];

frutas[0] = "manga";
frutas[1] = "uva";
frutas[2] = "maçã";

console.log("FOR CLASSICO");
for (let i= 0; i < meses.length; i++){
    console.log(meses[i]);
}

console.log("for ... of");
for (let mes of meses){
    console.log(mes);

}

meses.forEach( function(mes, i){
    console.log( `${i+1} ${mes}`)
})
